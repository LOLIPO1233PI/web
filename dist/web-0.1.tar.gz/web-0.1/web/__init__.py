import web.css
import web.html_
import web.js  # noqa: F401
